ESX = nil 

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)

------------------------FUNCTIONS------------------------

local IsHandcuffed, DragStatus = false, {}
DragStatus.IsDragged          = false
all_items, all_weapons = {}, {}

----- KeyboardInput
function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
	AddTextEntry('FMMC_KEY_TIP1', TextEntry)
	DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght) 
	while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do Wait(0) end
	if UpdateOnscreenKeyboard() ~= 2 then
		local result = GetOnscreenKeyboardResult()
		Wait(500) 
		return result
	else
		Wait(500) 
		return nil 
	end
end

----- Refresh Data Player
function RefreshPlayerData()
    CreateThread(function()
        Wait(10000)
        ESX.PlayerData = ESX.GetPlayerData()
    end)
end

----- DrawMaker
CreateThread(function()
    Wait(10)
    while true do
        local interval = 250
        local coord = GetEntityCoords(PlayerPedId())
		RefreshPlayerData()
		for k, v in pairs(Config.MarkerPolice) do
			if v.value == 0 then 
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
					local dist = GetDistanceBetweenCoords(coord, v.position, true)
					if dist < 5 then 
						interval = 1
						if v.marker then
							DrawMarker(22, v.position.x, v.position.y, v.position.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.4, 0.4, 0.4, v.color.r, v.color.g, v.color.b, v.color.a, 55555, false, true, 2, false, false, false, false)
						end
						if dist < 1.5 then 
							Visual.Subtitle(v.help)
							if IsControlJustPressed(1,51) then 
								RefreshPlayerData()
								v.interact()
								Wait(5000)
								v.interact2()
							end 
						elseif dist > 2 then
							RageUI.CloseAll()
							MENU_POLICE = false 
						end 
					end 
				end
			else
				local dist = GetDistanceBetweenCoords(coord, v.position, true)
				if dist < 5 then 
					interval = 1
					if v.marker then
						DrawMarker(22, v.position.x, v.position.y, v.position.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.4, 0.4, 0.4, v.color.r, v.color.g, v.color.b, v.color.a, 55555, false, true, 2, false, false, false, false)
					end
					if dist < 1.5 then 
						Visual.Subtitle(v.help)
						if IsControlJustPressed(1,51) then 
							RefreshPlayerData()
							v.interact()
							Wait(5000)
							v.interact2()
						end 
					elseif dist > 2 then
						RageUI.CloseAll()
						MENU_POLICE = false 
					end 
				end 
			end
		end
        Wait(interval)
    end 
end)

----- ProgressBar
function startUI(time, text) 
	SendNuiMessage(json.encode({
		type = "ui",
		display = true,
		time = time,
		text = text
	}))
end

----- Demande de Renfort
RegisterNetEvent('barwoz:renfortBlip')
AddEventHandler('barwoz:renfortBlip', function(coords, raison)
	if raison == 'petite' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Demande de renfort', 'Demande de renfort demandé.\nRéponse: ~g~CODE-2\n~w~Importance: ~g~Légère.', 'CHAR_CALL911', 8)
		Wait(500)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		color = 2
		text = 'Petite Demande'
	elseif raison == 'importante' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Demande de renfort', 'Demande de renfort demandé.\nRéponse: ~g~CODE-3\n~w~Importance: ~o~Importante.', 'CHAR_CALL911', 8)
		Wait(500)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		color = 47
		text = 'Demande Importante'
	elseif raison == 'big_importante' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		PlaySoundFrontend(-1, "FocusIn", "HintCamSounds", 1)
		ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Demande de renfort', 'Demande de renfort demandé.\nRéponse: ~g~CODE-99\n~w~Importance: ~r~URGENTE !\nDANGER IMPORTANT', 'CHAR_CALL911', 8)
		Wait(500)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "FocusOut", "HintCamSounds", 1)
		color = 1
		text = 'Demande Très Importante'
	end
	local blipId = AddBlipForCoord(coords)
	SetBlipSprite(blipId, 161)
	SetBlipScale(blipId, 1.2)
	SetBlipColour(blipId, color)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString(text)
	EndTextCommandSetBlipName(blipId)
	Wait(80 * 1000)
	RemoveBlip(blipId)
end)

----- Statut de l'Agent
RegisterNetEvent('barwoz:InfoService')
AddEventHandler('barwoz:InfoService', function(service, nom)
    if service == 'prise' then
        PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
        ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Prise de service', 'Agent: ~w~' .. nom .. '\n~w~Code: ~g~10-8\n~w~Information: ~g~Prise de service.', 'CHAR_CALL911', 8)
        Wait(1000)
        PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)

    elseif service == 'fin' then
        PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
        ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Fin de service', 'Agent: ~w~' .. nom .. '\n~w~Code: ~r~10-7\n~w~Information: ~r~Fin de service.', 'CHAR_CALL911', 8)
        Wait(1000)
        PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)

    elseif service == 'pause' then
        PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
        ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Pause de service', 'Agent: ~w~' .. nom .. '\n~w~Code: ~o~10-6\n~w~Information: ~o~Pause de service.', 'CHAR_CALL911', 8)
        Wait(1000)
        PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)

    elseif service == 'standby' then
        PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
        ESX.ShowAdvancedNotification('LSPD INFORMATIONS', '~b~Mise en standby','Agent: ~w~' .. nom .. '\n~w~Code: ~y~10-12\n~w~Information: ~y~Standby, en attente de dispatch.','CHAR_CALL911', 8)
        Wait(1000)
        PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
    end
end)

----- Amendes
function billingPolice(montant, name)
	local amount = montant
	local label = name
	local player, distance = ESX.Game.GetClosestPlayer()

	if player ~= -1 and distance <= 3.0 then
		if amount == nil then
			ESX.ShowNotification("~r~Problèmes~s~: Montant invalide")
		else
			TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(player), 'society_police', label, amount)
			Wait(100)
			ESX.ShowNotification("Vous avez bien envoyer ~b~l'amende : ~s~"..label.." avec un montant de : ~b~"..amount)
		end
	else
		ESX.ShowNotification("~r~Problèmes~s~: Aucun joueur à proximitée")
	end
end

----- Load Anim
function LoadAnimDict(dictname)
	if not HasAnimDictLoaded(dictname) then
		RequestAnimDict(dictname) 
		while not HasAnimDictLoaded(dictname) do 
			Citizen.Wait(1)
		end
	end
end

----- Mettre les Menottes
RegisterNetEvent('barwoz:mettreM')
AddEventHandler('barwoz:mettreM', function(playerheading, playercoords, playerlocation)
	playerPed = GetPlayerPed(-1)
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'), true) -- unarm player
	SetPedCanPlayGestureAnims(playerPed, false)
	DisablePlayerFiring(playerPed, true)
	DisplayRadar(false)
	local x, y, z   = table.unpack(playercoords + playerlocation * 1.0)
	Wait(500)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	Wait(250)
	LoadAnimDict('mp_arrest_paired')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arrest_paired', 'crook_p2_back_right', 8.0, -8, 3750 , 2, 0, 0, 0, 0)
	Wait(3760)
	IsHandcuffed = true
	LoadAnimDict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0.0, false, false, false)
end)

RegisterNetEvent('barwoz:animarrest')
AddEventHandler('barwoz:animarrest', function()
	Wait(250)
	LoadAnimDict('mp_arrest_paired')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arrest_paired', 'cop_p2_back_right', 8.0, -8,3750, 2, 0, 0, 0, 0)
	Wait(3000)
end) 

----- Enlever les Menottes

RegisterNetEvent('barwoz:enleverM')
AddEventHandler('barwoz:enleverM', function(playerheading, playercoords, playerlocation)
	local x, y, z   = table.unpack(playercoords + playerlocation)
	SetEntityCoords(GetPlayerPed(-1), x, y, z)
	FreezeEntityPosition(playerPed, false)
	SetEntityHeading(GetPlayerPed(-1), playerheading)
	SetPedCanPlayGestureAnims(playerPed, true)
	DisablePlayerFiring(playerPed, false)
	DisplayRadar(true)
	Wait(250)
	LoadAnimDict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'b_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Wait(5500)
	IsHandcuffed = false
	ClearPedTasks(GetPlayerPed(-1))
end)

RegisterNetEvent('barwoz:animenlevermenottes')
AddEventHandler('barwoz:animenlevermenottes', function()
	Wait(250)
	LoadAnimDict('mp_arresting')
	TaskPlayAnim(GetPlayerPed(-1), 'mp_arresting', 'a_uncuff', 8.0, -8,-1, 2, 0, 0, 0, 0)
	Wait(5500)
	ClearPedTasks(GetPlayerPed(-1))
end)

----- Disable Actions

CreateThread(function()
	while true do 
		Wait(0)
		if IsHandcuffed == true then
			DisableControlAction(0, 24, true) -- Attack
			DisableControlAction(0, 257, true) -- Attack 2
			DisableControlAction(0, 25, true) -- Aim
			DisableControlAction(0, 263, true) -- Melee Attack 1
			DisableControlAction(0, 37, true) -- Select Weapon
			DisableControlAction(0, 47, true)  -- Disable weapon
		end
	end 
end)

----- Mettre dans un Véhicule

RegisterNetEvent('barwoz:putInVehicle')
AddEventHandler('barwoz:putInVehicle', function()
	local playerPed = PlayerPedId()
	local coords    = GetEntityCoords(playerPed)
	if not IsHandcuffed then
		return
	end
	if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then
		local vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
		if DoesEntityExist(vehicle) then
			local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
			local freeSeat = nil
			for i=maxSeats - 1, 0, -1 do
				if IsVehicleSeatFree(vehicle, i) then
					freeSeat = i
					break
				end
			end
			if freeSeat ~= nil then
				TaskWarpPedIntoVehicle(playerPed, vehicle, freeSeat)
				DragStatus.IsDragged = false
			end
		end
	end
end)

----- Sortir d'un Véhicule

RegisterNetEvent('barwoz:OutVehicle')
AddEventHandler('barwoz:OutVehicle', function()
	local playerPed = PlayerPedId()
	if not IsPedSittingInAnyVehicle(playerPed) then
		return
	end
	local vehicle = GetVehiclePedIsIn(playerPed, false)
	TaskLeaveVehicle(playerPed, vehicle, 16)
end)

----- Crocheter un Véhicule

function OpenVehicleSinKey(vehicle, playerPed)
	isBusy = true
	TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_WELDING', 10000, true)
	startUI(Config.ProgressBar.Time.Vehicle_Open, Config.ProgressBar.Text['Vehicle_Open'])
	Wait(20000)
	CreateThread(function()
		Wait(0000)
		SetVehicleDoorsLocked(vehicle, 1)
		SetVehicleDoorsLockedForAllPlayers(vehicle, false)
		ClearPedTasksImmediately(playerPed)
		ESX.ShowNotification("Ouverture du ~y~Véhicule~s~ bien ~g~Effectué~s~ !")
		isBusy = false
	end)
end

----- Mettre un Véhicule en Fouriere

function VehicleToFouriere(vehicle, playerPed)
	TaskStartScenarioInPlace(playerPed, 'CODE_HUMAN_MEDIC_TEND_TO_DEAD', 5000, true)
	startUI(Config.ProgressBar.Time.Fouriere, Config.ProgressBar.Text['Fouriere'])
	Wait(8000)
	ESX.Game.DeleteVehicle(vehicle)
	ESX.ShowNotification("Mise en ~y~Fourière~s~ bien ~g~Effectué~s~ !")
end

----- Load Dict
loadDict = function(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) RequestAnimDict(dict) end
end

----- Get Stock Police

function getStockPolice()
    ESX.TriggerServerCallback('barwoz:getStockItemsPolice', function(inventory)               
        all_items = inventory        
    end)
end

----- Weapon Police

function getWeaponsPolice()
	ESX.TriggerServerCallback('barwoz:getWeaponsPolice', function(weapons)
		all_weapons = weapons
	end)
end

----- Blips

CreateThread(function()
	for _, info in pairs(Config.blipsPoliceJob) do
		info.blip = AddBlipForCoord(info.x, info.y, info.z)
		SetBlipSprite(info.blip, info.id)
		SetBlipDisplay(info.blip, 4)
		SetBlipScale(info.blip, 0.7)
		SetBlipColour(info.blip, info.colour)
		SetBlipAsShortRange(info.blip, true)
		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString(info.title)
		EndTextCommandSetBlipName(info.blip)
	end
end)
	