ESX = nil 

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)
    
Style = {
    Line = { 10, 100, 170, 225 }
}
LineColor = Style

MENU_POLICE = false

local weaponpolice = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title4'], Config.Locales[Config.Locale]['Menu_SubTitle4'])
weaponpolice:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
weaponpolice.Closed = function()
    MENU_POLICE = false
end

function OpenWeaponMenuPolice()
    if MENU_POLICE then
        MENU_POLICE = false
        RageUI.Visible(weaponpolice, false)
    else
        MENU_POLICE = true
        RageUI.Visible(weaponpolice, true)
        CreateThread(function()
            while MENU_POLICE do
                Wait(1)
                RageUI.IsVisible(weaponpolice, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Armes) do
                        if v.grade == 0 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'recruit' or ESX.PlayerData.job.grade_name == 'officer' or ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'capitaine' or ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                        if v.grade == 1 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'officer' or ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'capitaine' or ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                        if v.grade == 2 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'sergeant' or ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'capitaine' or ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                        if v.grade == 3 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'lieutenant' or ESX.PlayerData.job.grade_name == 'capitaine' or ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                        if v.grade == 4 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'capitaine' or ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                        if v.grade == 5 then
                            if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'boss' then 
                                RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                                    onSelected = function()
                                        TriggerServerEvent('barwoz:TakeWeaponsPolice', v.name, v.label)
                                    end
                                })
                            end
                        end
                    end
                    RageUI.Line(LineColor)
                end)
            end
        end)
    end
end