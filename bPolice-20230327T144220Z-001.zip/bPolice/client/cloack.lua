ESX = nil 

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)
    
Style = {
    Line = { 10, 100, 170, 225 }
}
LineColor = Style

MENU_POLICE = false

local cloakpolice = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title2'], Config.Locales[Config.Locale]['Menu_SubTitle2'])
cloakpolice:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
cloakpolice.Closed = function()
    MENU_POLICE = false
end

function OpenCloakMenuPolice()
    if MENU_POLICE then
        MENU_POLICE = false
        RageUI.Visible(cloakpolice, false)
    else
        MENU_POLICE = true
    RageUI.Visible(cloakpolice, true)
        CreateThread(function()
            while MENU_POLICE do
                Wait(1)
                RageUI.IsVisible(cloakpolice, function()
                    RageUI.Line(LineColor)
                    RageUI.Button('Reprendre sa ~b~Tenue~s~', nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                                TriggerEvent('skinchanger:loadSkin', skin)
                            end)
                        end
                    })
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Tenues) do
                        RageUI.Button(v.name, nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                SetPedComponentVariation(GetPlayerPed(-1), 8, v.shirt1, v.shirt2) -- (T-shirt)
                                SetPedComponentVariation(GetPlayerPed(-1), 11, v.torse1, v.torce2) -- (Torse)
                                SetPedComponentVariation(GetPlayerPed(-1), 3, v.bras1, v.bras2) -- (Bras)
                                SetPedComponentVariation(GetPlayerPed(-1), 4, v.pantalon1, v.pantalon2) -- (Pantalon)
                                SetPedComponentVariation(GetPlayerPed(-1), 6, v.chaussure1, v.chaussure2) -- (Chaussure)
                                SetPedComponentVariation(GetPlayerPed(-1), 7, v.chaine1, v.chaine2) -- (Chaine)
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Bullet) do
                        RageUI.Button(Config.Locales[Config.Locale]['Took_Bullet'], nil, {RightLabel = ""},
                                    true, {
                            onSelected = function()
                                SetPedComponentVariation(GetPlayerPed(-1), 9, v.bullet1, v.bullet2) -- (Gilet par balle)  
                            end
                        })
                    end
                    if ESX.PlayerData.job.name == 'police' and ESX.PlayerData.job.grade_name == 'recruit' then
                        for k,v in pairs(Config.BulletCadet) do
                            RageUI.Button(Config.Locales[Config.Locale]['Took_BulletCadet'], nil, {RightLabel = ""}, true, {
                                onSelected = function()
                                    SetPedComponentVariation(GetPlayerPed(-1), 9, v.bulletcadet1, v.bulletcadet2) -- (Gilet par balle)  
                                end
                            })
                        end
                    end
                    for k,v in pairs(Config.Bag) do
                        RageUI.Button(Config.Locales[Config.Locale]['Took_Bag'], nil, {RightLabel = ""}, true, {
                            onSelected = function()
                                SetPedComponentVariation(GetPlayerPed(-1), 5, v.bag1, v.bag2) -- (Sac Police)  
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
            end
        end)
    end
end

local Cloack_Jail = false

local cloakjail = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title3'], Config.Locales[Config.Locale]['Menu_SubTitle3'])
cloakjail:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
cloakjail.Closed = function()
    Cloack_Jail = false
end

function OpenCloakMenuJail()
    if Cloack_Jail then
        Cloack_Jail = false
        RageUI.Visible(cloakjail, false)
    else
        Cloack_Jail = true
    RageUI.Visible(cloakjail, true)
        CreateThread(function()
            while Cloack_Jail do
                Wait(1)
                RageUI.IsVisible(cloakjail, function()
                    RageUI.Line(LineColor)
                    RageUI.Button('Reprendre ses ~b~Affaires~s~', nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                                TriggerEvent('skinchanger:loadSkin', skin)
                            end)
                        end
                    })
                    for k,v in pairs(Config.TenuesJail) do
                        RageUI.Button(v.name, nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                SetPedComponentVariation(GetPlayerPed(-1), 8, v.shirt1, v.shirt2) -- (T-shirt)
                                SetPedComponentVariation(GetPlayerPed(-1), 11, v.torse1, v.torce2) -- (Torse)
                                SetPedComponentVariation(GetPlayerPed(-1), 3, v.bras1, v.bras2) -- (Bras)
                                SetPedComponentVariation(GetPlayerPed(-1), 4, v.pantalon1, v.pantalon2) -- (Pantalon)
                                SetPedComponentVariation(GetPlayerPed(-1), 6, v.chaussure1, v.chaussure2) -- (Chaussure)
                                SetPedComponentVariation(GetPlayerPed(-1), 7, v.chaine1, v.chaine2) -- (Chaine)
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
            end
        end)
    end
end
