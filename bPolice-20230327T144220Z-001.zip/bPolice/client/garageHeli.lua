ESX = nil 

TriggerEvent(Config.InitESX, function(obj) ESX = obj end)

Style = {
Line = { 10, 100, 170, 225 }
}
LineColor = Style

MENU_POLICE = false

local garagehelipolice = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title7'], Config.Locales[Config.Locale]['Menu_SubTitle7'])
garagehelipolice:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
garagehelipolice.Closed = function() 
    MENU_POLICE = false 
end

function OpenGarageHeliMenuPolice()
    if MENU_POLICE then
        MENU_POLICE = false
        RageUI.Visible(garagehelipolice, false)
    else
        MENU_POLICE = true
        RageUI.Visible(garagehelipolice, true)
        CreateThread(function()
            while MENU_POLICE do
                Wait(1)
                RageUI.IsVisible(garagehelipolice, function()
                    RageUI.Line(LineColor)
                    RageUI.Button("Ranger l'Hélicoptère", nil, {RightLabel = "→→"}, true, { 
                        onSelected = function()
                            local veh, dist = ESX.Game.GetClosestVehicle(playerCoords)
                            if dist < 4 then
                                DeleteEntity(veh)
                            end
                        end
                    })
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.HeliPolice) do
                        RageUI.Button(v.label, nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                local model = GetHashKey(v.model)
                                RequestModel(model)
                                while not HasModelLoaded(model) do
                                    Wait(10)
                                end
                                local pos = GetEntityCoords(PlayerPedId())
                                local vehicle = CreateVehicle(model, pos.x, pos.y, pos.z, 90.0, true, false)
                                TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
            end 
        end) 
    end 
end