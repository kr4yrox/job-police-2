ESX = nil 

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)

Style = {
    Line = { 10, 100, 170, 225 }
}
LineColor = Style

local PoliceService, TextService, InfosPlayers, CooldownRenfort, CooldownStatues, BlackMoneyPlayers, Items, Armes, menoteLabel, MenoteActive, inVehicleLabel, InVehicleActive, EscortLabel, EscortIsActive, VehicleInfo, PlayerLicences = false, '~y~Prendre~s~ vôtre service !', {}, true, true, {}, {}, {},  '~y~Menotter~s~ un Joueur !', false, '~y~Mettre~s~ dans le Véhicule !', false, '~y~Escorter~s~ un Joueur !', false, {}, {}
MENU_POLICE = false 

local name, prenom, dateofbirth, taille, date, faits, sanction = '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→'
local datalist = {}
local valid_casier = false

Index = {
    List1 = 1
} 

local function RefreshInfosTarget(player)
    Items = {}
	Armes = {}

    ESX.TriggerServerCallback('barwoz:sendInfosPlayerTrg', function(infos) 
        InfosPlayers = infos
    end, GetPlayerServerId(player))

    ESX.TriggerServerCallback('barwoz:sendBlackMoneyPlayer', function(blackmoney) 
        BlackMoneyPlayers = blackmoney
    end, GetPlayerServerId(player))

    ESX.TriggerServerCallback('barwoz:sendItemPlayer', function(data) 
        for i=1, #data.weapons, 1 do
			table.insert(Armes, {
				label    = ESX.GetWeaponLabel(data.weapons[i].name),
				value    = data.weapons[i].name,
				right    = data.weapons[i].ammo,
				itemType = 'item_weapon',
				amount   = data.weapons[i].ammo,
			})
		end
		for i=1, #data.inventory, 1 do
			if data.inventory[i].count > 0 then
				table.insert(Items, {
					label    = data.inventory[i].label,
					right    = data.inventory[i].count,
					value    = data.inventory[i].name,
					itemType = 'item_standard',
					amount   = data.inventory[i].count,
				})
			end
	    end
    end, GetPlayerServerId(player))    
end

function RefreshDataVehicleInfos(id_veh)
    ESX.TriggerServerCallback('barwoz:getInfosVehicle', function(ivehicle)
        VehicleInfo = ivehicle
    end, id_veh)
end

function ShowPlayerLicense(player)
    ESX.TriggerServerCallback('barwoz:getLicencesPlayer', function(licencePlayer)
        PlayerLicences = licencePlayer
    end, GetPlayerServerId(player))
end

Infos_Player_Casier = {}

function RefreshPlayerCasier(LastNameCasier)
    ESX.TriggerServerCallback('barwoz:getCasierPolice', function(infos_casier)
        Infos_Player_Casier = infos_casier
    end, LastNameCasier)
end

OpenMenuPoliceF6 = function() 

local policemenu = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title'], Config.Locales[Config.Locale]['Menu_SubTitle']..ESX.PlayerData.job.grade_label, 10, 10)
local interact_civilmenu = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title1'], Config.Locales[Config.Locale]['SubMenu_SubTitle1'])
local identity_infos = RageUI.CreateSubMenu(interact_civilmenu, Config.Locales[Config.Locale]['SubMenu_Title2'], Config.Locales[Config.Locale]['SubMenu_SubTitle2'])
local statues = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title3'], Config.Locales[Config.Locale]['SubMenu_SubTitle3'])
local fouille_menu = RageUI.CreateSubMenu(interact_civilmenu, Config.Locales[Config.Locale]['SubMenu_Title4'], Config.Locales[Config.Locale]['SubMenu_SubTitle4'])
local fines_menu = RageUI.CreateSubMenu(interact_civilmenu, Config.Locales[Config.Locale]['SubMenu_Title5'], Config.Locales[Config.Locale]['SubMenu_SubTitle5'])
local fines_1 = RageUI.CreateSubMenu(fines_menu, Config.Locales[Config.Locale]['SubMenu_Title6'], Config.Locales[Config.Locale]['SubMenu_SubTitle6'])
local fines_2 = RageUI.CreateSubMenu(fines_menu, Config.Locales[Config.Locale]['SubMenu_Title7'], Config.Locales[Config.Locale]['SubMenu_SubTitle7'])
local fines_3 = RageUI.CreateSubMenu(fines_menu, Config.Locales[Config.Locale]['SubMenu_Title8'], Config.Locales[Config.Locale]['SubMenu_SubTitle8'])
local casier = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title9'], Config.Locales[Config.Locale]['SubMenu_SubTitle9'])
local menu_maked_casier = RageUI.CreateSubMenu(casier, Config.Locales[Config.Locale]['SubMenu_Title9'], Config.Locales[Config.Locale]['SubMenu_SubTitle9'])
local menu_consult_casier = RageUI.CreateSubMenu(casier, Config.Locales[Config.Locale]['SubMenu_Title9'], Config.Locales[Config.Locale]['SubMenu_SubTitle9'])
local handcuff = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title10'], Config.Locales[Config.Locale]['SubMenu_SubTitle10'])
local vehicle_menu = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title12'], Config.Locales[Config.Locale]['SubMenu_SubTitle12'])
local vehicle_infos = RageUI.CreateSubMenu(vehicle_menu, Config.Locales[Config.Locale]['SubMenu_Title13'], Config.Locales[Config.Locale]['SubMenu_SubTitle13'])
local dogs_menu = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title14'], Config.Locales[Config.Locale]['SubMenu_SubTitle14'])
local askrenfort = RageUI.CreateSubMenu(policemenu, Config.Locales[Config.Locale]['SubMenu_Title11'], Config.Locales[Config.Locale]['SubMenu_SubTitle11'])
policemenu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
interact_civilmenu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
identity_infos:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
statues:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
fouille_menu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
fines_menu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
fines_1:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
fines_2:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
fines_3:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
casier:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
menu_maked_casier:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
menu_consult_casier:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
handcuff:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
vehicle_menu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
vehicle_infos:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
dogs_menu:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
askrenfort:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
policemenu.Closed = function() 
    MENU_POLICE = false
end

    if MENU_POLICE then 
        MENU_POLICE = false 
    else 
        MENU_POLICE = true 
        RageUI.Visible(policemenu, true)
        CreateThread(function()
            while MENU_POLICE do 
                Wait(1)                    
                RageUI.IsVisible(policemenu, function()
                    RageUI.Checkbox(TextService, nil, PoliceService, {}, {
                        onChecked = function()
                            PoliceService = true
                            TextService = '~r~Quitter vôtre service !'
                        end,
                        onUnChecked = function()
                            PoliceService = false
                            TextService = '~y~Prendre~s~ vôtre service !'
                        end
                    })
                    if PoliceService == true then
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Statues'], nil, {RightLabel = '→→'}, true, {}, statues)
                        RageUI.Button(Config.Locales[Config.Locale]['Interact_Person'], nil, {RightLabel = '→→'}, true, {}, interact_civilmenu)
                        RageUI.Button(Config.Locales[Config.Locale]['Casier'], nil, {RightLabel = '→→'}, true, {}, casier)
                        RageUI.Button(Config.Locales[Config.Locale]['Menottes'], nil, {RightLabel = '→→'}, true, {}, handcuff)
                        RageUI.Button(Config.Locales[Config.Locale]['Interact_Veh'], nil, {RightLabel = '→→'}, true, {}, vehicle_menu)                   
                        RageUI.Button(Config.Locales[Config.Locale]['Dogs'], nil, {RightLabel = '→→'}, true, {}, dogs_menu)
                        RageUI.Button(Config.Locales[Config.Locale]['Renfort'], nil, {RightLabel = '→→'}, true, {}, askrenfort)                        
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Quit'], nil, {Color = {BackgroundColor = {255, 0, 0, 100}}, RightLabel = '→→'}, true, {
                            onSelected = function()
                                RageUI.CloseAll()
                                MENU_POLICE = false
                            end
                        })  
                    else
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Quit'], nil, {Color = {BackgroundColor = {255, 0, 0, 100}}, RightLabel = '→→'}, true, {
                            onSelected = function()
                                RageUI.CloseAll()
                                MENU_POLICE = false
                            end
                        })  
                    end
                end)
                RageUI.IsVisible(statues, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Statues) do
                        RageUI.Button(v.name, nil, {RightLabel = '→→'}, CooldownStatues, {
                            onSelected = function()
                                CooldownStatues = false
                                local _reason = v.reason
                                startUI(Config.ProgressBar.Time.Statues, Config.ProgressBar.Text['Statues'])
                                Wait(3000)
                                TriggerServerEvent('barwoz:statues', _reason)
                                CooldownStatues = true
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(interact_civilmenu, function()
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                    if closestPlayer ~= -1 and closestDistance <= 3.0 then
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Identity_Card'], nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                RefreshInfosTarget(closestPlayer)
                                target = closestPlayer
                                print(closestPlayer)
                                ID = GetPlayerServerId(closestPlayer)
                            end
                        }, identity_infos)
                        RageUI.Button(Config.Locales[Config.Locale]['Fouille'], nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                RefreshInfosTarget(closestPlayer)
                                target = closestPlayer
                            end
                        }, fouille_menu)
                    else
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Identity_Card'], nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                ESX.ShowNotification('~r~Aucun joueur proche')
                            end
                        })
                        RageUI.Button(Config.Locales[Config.Locale]['Fouille'], nil, {RightLabel = '→→'}, true, {
                            onSelected = function()
                                ESX.ShowNotification('~r~Aucun joueur proche')
                            end
                        })
                    end
                    RageUI.Button(Config.Locales[Config.Locale]['Amendes'], nil, {RightLabel = '→→'}, true, {}, fines_menu)
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(identity_infos, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(InfosPlayers) do
                        RageUI.Button(Config.Locales[Config.Locale]['LastName']..v.LastName, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['FirstName']..v.FirstName, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Sex']..v.Sex, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['DateOfBirth']..v.DateOfBirth, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Height']..v.Height, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Job']..v.Job, nil, {}, true, {})
                        RageUI.Button(Config.Locales[Config.Locale]['ID']..ID, nil, {}, true, {})
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(fouille_menu, function()
                    RageUI.Line(LineColor)
                    RageUI.List(Config.Locales[Config.Locale]['Filter_Fouille'], {'Items','Armes','Money'}, Index.List1, nil, {}, true, {
                        onListChange = function(i, item)
                            Index.List1 = i;
                            local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                            RefreshInfosTarget(closestPlayer)
                        end,
                    })
                    if Index.List1 == 1 then
                        RageUI.Line(LineColor)
                        for k, v in pairs(Items) do
                            RageUI.Button(v.label, nil, {RightLabel = "~b~x"..v.right}, true, {
                                onSelected = function()
                                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                    TriggerServerEvent('barwoz:TakeItems', GetPlayerServerId(closestPlayer), v.itemType, v.value, v.amount)
                                    RefreshInfosTarget(closestPlayer)
                                end                               
                            })
                        end
                        RageUI.Line(LineColor)
                    elseif Index.List1 == 2 then
                        RageUI.Line(LineColor)
                        for k, v in pairs(Armes) do
                            RageUI.Button(v.label, nil, {RightLabel = "~b~x"..v.right}, true, {
                                onSelected = function()
                                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                    TriggerServerEvent('barwoz:TakeItems', GetPlayerServerId(closestPlayer), v.itemType, v.value, v.amount)
                                    RefreshInfosTarget(closestPlayer)
                                end  
                            })
                        end
                        RageUI.Line(LineColor)
                    elseif Index.List1 == 3 then
                        RageUI.Line(LineColor)
                        for k,v in pairs(BlackMoneyPlayers) do
                            RageUI.Button(Config.Locales[Config.Locale]['BlackMoney']..v.BlackMoney, nil, {}, true, {
                                onSelected = function()
                                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                    local quantityblackmoney = KeyboardInput('Combien de Argent Liquide voulez-vous saisir ?', '', 9)
                                    if tonumber(quantityblackmoney) > v.BlackMoney then
                                        ESX.ShowNotification('~r~Quantité invalide')
                                    else
                                        TriggerServerEvent('barwoz:TakeItems', GetPlayerServerId(closestPlayer), 'item_account', 'black_money', tonumber(quantityblackmoney))
                                        RefreshInfosTarget(closestPlayer)
                                    end
                                end  
                            })
                        end
                        for k,v in pairs(InfosPlayers) do
                            RageUI.Button(Config.Locales[Config.Locale]['Money']..v.Money, nil, {}, true, {
                                onSelected = function()
                                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                    local quantitymoney = KeyboardInput('Combien de Argent Liquide voulez-vous saisir ?', '', 9)
                                    if tonumber(quantitymoney) > v.Money then
                                        ESX.ShowNotification('~r~Quantité invalide')
                                    else
                                        TriggerServerEvent('barwoz:TakeItems', GetPlayerServerId(closestPlayer), 'item_money', '', tonumber(quantitymoney))
                                        RefreshInfosTarget(closestPlayer)
                                    end 
                                end  
                            })
                        end
                        RageUI.Line(LineColor)
                    end
                end)
                RageUI.IsVisible(fines_menu, function()
                    RageUI.Line(LineColor)
                    RageUI.Button(Config.Locales[Config.Locale]['Fines_1'], nil, {RightLabel = '→→'}, true, {}, fines_1)
                    RageUI.Button(Config.Locales[Config.Locale]['Fines_2'], nil, {RightLabel = '→→'}, true, {}, fines_2)
                    RageUI.Button(Config.Locales[Config.Locale]['Fines_3'], nil, {RightLabel = '→→'}, true, {}, fines_3)
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(fines_1, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Fines) do 
                        if v.category == "0" then
                            RageUI.Button(v.label, nil, {RightLabel = '~r~'..v.amount..' ~s~$'}, true, {
                                onSelected = function()
                                    billingPolice(v.amount, v.label)
                                end
                            })
                        end
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(fines_2, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Fines) do 
                        if v.category == "1" then
                            RageUI.Button(v.label, nil, {RightLabel = '~r~'..v.amount..' ~s~$'}, true, {
                                onSelected = function()
                                    billingPolice(v.amount, v.label)
                                end
                            })
                        end
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(fines_3, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Fines) do 
                        if v.category == "2" then
                            RageUI.Button(v.label, nil, {RightLabel = '~r~'..v.amount..' ~s~$'}, true, {
                                onSelected = function()
                                    billingPolice(v.amount, v.label)
                                end
                            })
                        end
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(casier, function()
                    RageUI.Line(LineColor)
                    RageUI.Button('Consulter un Casier', nil, {RightLabel = '→→'}, true, {}, menu_consult_casier)
                    RageUI.Button('Faire un Casier', nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            name, prenom, dateofbirth, taille, date, faits, sanction = '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→', '~b~→→'
                        end
                    }, menu_maked_casier)
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(menu_consult_casier, function()
                    RageUI.Line(LineColor)
                    RageUI.Button('Recherche un ~b~Détenue', nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            detenue = KeyboardInput('Nom de la Personne Recherché', '', 15)
                            RefreshPlayerCasier(detenue)
                        end
                    })
                    RageUI.Line(LineColor)
                    for i=1, #Infos_Player_Casier do
                        if tostring(detenue) ~= "" or tostring(detenue) == "Detenue" then
                            RageUI.Button('~b~Date du Casier~s~ : '..Infos_Player_Casier[i].DateOfCrimes_Casier, "~b~Prénom~s~ : "..Infos_Player_Casier[i].FirstName_Casier.."\n~b~Nom~s~ : "..Infos_Player_Casier[i].LastName_Casier.."\n~b~Date de Naissance~s~ : "..Infos_Player_Casier[i].DateOfBirth_Casier.."\n~b~Taille~s~ : "..Infos_Player_Casier[i].Height_Casier..'\n~y~Faits Reproché~s~ : '..Infos_Player_Casier[i].Crimes_Casier..'\n~r~Sanctions Données~s~ : '..Infos_Player_Casier[i].Sanctions_Casier, {}, true, {})
                        end
                    end
                end)
                RageUI.IsVisible(menu_maked_casier, function()
                    RageUI.Button('Nom', nil, {RightLabel = "~b~"..name}, true, {
                        onSelected = function()
                            name = KeyboardInput('Nom de la Personne', '', 15)
                            if tostring(name) == "" or tostring(name) == "Nom" then 
                                name = "[]"
                            else
                                name = tostring(name)
                                datalist.lastname = name
                            end
                        end
                    })
                    RageUI.Button('Prénom', nil, {RightLabel = "~b~"..prenom}, true, {
                        onSelected = function()
                            prenom = KeyboardInput('Prenom de la Personne', '', 15)
                            if tostring(prenom) == "" or tostring(prenom) == "Prenom" then 
                                prenom = "[]"
                            else
                                prenom = tostring(prenom)
                                datalist.firstname = prenom
                            end
                        end
                    })
                    RageUI.Button('Date de Naissance', nil, {RightLabel = "~b~"..dateofbirth}, true, {
                        onSelected = function()
                            dateofbirth = KeyboardInput('Date de Naissance de la Personne (jj/mm/aaaa)', '', 10)
                            if tostring(dateofbirth) == "" or tostring(dateofbirth) == "Date de Naissance" or #dateofbirth < 8 then 
                                dateofbirth = "[]"
                            else
                                dateofbirth = tostring(dateofbirth)
                                datalist.dateofbirth = dateofbirth
                            end
                        end
                    })
                    RageUI.Button('Taille', nil, {RightLabel = "~b~"..taille}, true, {
                        onSelected = function()
                            taille = KeyboardInput("Taille :", nil, 3)
                            if tostring(taille) == "" or tostring(taille) == "Taille" or #taille < 3 then 
                                taille = "[]"
                            else
                                taille = GetOnscreenKeyboardResult()
                                datalist.height = taille
                            end
                        end
                    })
                    RageUI.Button('Date Des Faits', nil, {RightLabel = "~b~"..date}, true, {
                        onSelected = function()
                            date = KeyboardInput('Date des Faits (jj/mm/aaaa)', '', 10)
                            if tostring(date) == "" or tostring(date) == "Date de Naissance" or #date < 8 then 
                                date = "[]"
                            else
                                date = tostring(date)
                                datalist.date = date
                            end
                        end
                    })
                    RageUI.Button('Faits Reproché', "~b~Faits Reproché : ~s~"..faits, {RightLabel = '~b~→→'}, true, {
                        onSelected = function()
                            faits = KeyboardInput('Date des Faits (jj/mm/aaaa)', '', 200)
                            if tostring(faits) == "" or tostring(faits) == "Faits" then 
                                faits = "[]"
                            else
                                faits = tostring(faits)
                                datalist.faits = faits
                            end
                        end
                    })
                    RageUI.Button('Sanctions', nil, {RightLabel = '~b~'..sanction}, true, {
                        onSelected = function()
                            sanction = KeyboardInput('Sanctions', '', 50)
                            if tostring(sanction) == "" or tostring(sanction) == "Sanctions" then 
                                sanction = "[]"
                                valid_casier = false
                            else
                                sanction = tostring(sanction)
                                datalist.sanction = sanction
                                valid_casier = true
                            end
                        end
                    })
                    RageUI.Button('Valider le Casier', nil, {RightLabel = '~b~→→'}, valid_casier, {
                        onSelected = function()
                            TriggerServerEvent('barwoz:savedCasierPolice', datalist.lastname, datalist.firstname, datalist.dateofbirth, datalist.height, datalist.date, datalist.faits, datalist.sanction)
                        end
                    }, casier)
                end)
                RageUI.IsVisible(handcuff, function()
                    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
					if closestPlayer ~= -1 and closestDistance < 3 then
                        RageUI.Line(LineColor)
                        RageUI.Checkbox(menoteLabel, nil, MenoteActive, {}, {
                            onChecked = function()
                                menoteLabel = '~r~Démenotter~s~ un Joueur !'
                                MenoteActive = true
                                local target_id = GetPlayerServerId(closestPlayer)
                                playerheading = GetEntityHeading(GetPlayerPed(-1))
                                playerlocation = GetEntityForwardVector(PlayerPedId())
                                playerCoords = GetEntityCoords(GetPlayerPed(-1))
                                if closestDistance <= 2.0 then
                                    TriggerServerEvent('barwoz:mettremenotte', target_id, playerheading, playerCoords, playerlocation)
                                end
                            end,
                            onUnChecked = function()
                                menoteLabel = '~y~Menotter~s~ un Joueur !'
                                MenoteActive = false
                                local target_id = GetPlayerServerId(closestPlayer)
                                playerheading = GetEntityHeading(GetPlayerPed(-1))
                                playerlocation = GetEntityForwardVector(PlayerPedId())
                                playerCoords = GetEntityCoords(GetPlayerPed(-1))
                                if closestDistance <= 2.0 then
                                    TriggerServerEvent('barwoz:enlevermenotte', target_id, playerheading, playerCoords, playerlocation)
                                end
                            end
                        })
                        RageUI.Checkbox(inVehicleLabel, nil, InVehicleActive, {}, {
                            onChecked = function()
                                inVehicleLabel = '~r~Sortir~s~ du Véhicule !'
                                InVehicleActive = true
                                if closestDistance <= 2.0 then
                                    TriggerServerEvent('barwoz:putInVehicle', GetPlayerServerId(closestPlayer))
                                end
                            end,
                            onUnChecked = function()
                                inVehicleLabel = '~y~Mettre~s~ dans le Véhicule !'
                                InVehicleActive = false
                                if closestDistance <= 2.0 then
                                    TriggerServerEvent('barwoz:OutVehicle', GetPlayerServerId(closestPlayer))
                                end
                            end
                        })
                        RageUI.Line(LineColor)
                    else 
                        RageUI.Separator("")RageUI.Separator("~r~Personnes aux alentours")RageUI.Separator("")
                    end
                end)
                RageUI.IsVisible(vehicle_menu, function()
                    local playerPed = PlayerPedId()
                    local vehicle   = ESX.Game.GetVehicleInDirection()
                    local coords    = GetEntityCoords(playerPed)
            
                    if IsPedSittingInAnyVehicle(playerPed) then
                        RageUI.Button(Config.Locales[Config.Locale]['Get_Plate'], nil, {}, false, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Fouriere'], nil, {}, false, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Open_Vehicle'], nil, {}, false, {})
                        return
                    end
            
                    if DoesEntityExist(vehicle) then
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Get_Plate'], nil, {}, true, {
                            onSelected = function()
                                Plate_VehicleTarget = ESX.Math.Trim(GetVehicleNumberPlateText(vehicle))
                                RefreshDataVehicleInfos(Plate_VehicleTarget)
                            end
                        }, vehicle_infos) 
                        RageUI.Button(Config.Locales[Config.Locale]['Fouriere'], nil, {}, true, {
                            onSelected = function()
                                VehicleToFouriere(vehicle, playerPed)
                            end
                        })
                        RageUI.Button(Config.Locales[Config.Locale]['Open_Vehicle'], nil, {}, true, {
                            onSelected = function()
                                OpenVehicleSinKey(vehicle, playerPed)
                            end
                        })   
                        RageUI.Line(LineColor)       
                    else
                        RageUI.Line(LineColor)
                        RageUI.Button(Config.Locales[Config.Locale]['Get_Plate'], nil, {}, false, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Fouriere'], nil, {}, false, {})
                        RageUI.Button(Config.Locales[Config.Locale]['Open_Vehicle'], nil, {}, false, {})
                        RageUI.Line(LineColor)
                    end                     
                end)
                RageUI.IsVisible(vehicle_infos, function()
                    if VehicleInfo == 'rien' then
                        RageUI.Separator("")RageUI.Separator("~r~Aucunes Données Disponible")RageUI.Separator("")
                    else 
                        for k,v in pairs(VehicleInfo) do
                            RageUI.Line(LineColor)
                            RageUI.Button(Config.Locales[Config.Locale]['Plate']..Plate_VehicleTarget, nil, {}, true, {})
                            RageUI.Button(Config.Locales[Config.Locale]['NameP_Veh']..v.LastName..' '..v.FirstName, nil, {}, true, {})
                            RageUI.Line(LineColor)
                        end
                    end
                end)
                RageUI.IsVisible(dogs_menu, function()
                    RageUI.Line(LineColor)
                    RageUI.Button(Config.Locales[Config.Locale]['Dogs_1'], nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            if not DoesEntityExist(policeDog) then
                                RequestModel(351016938)
                                while not HasModelLoaded(351016938) do Wait(0) end
                                policeDog = CreatePed(4, 351016938, GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 1.0, -0.98), 0.0, true, false)
                                SetEntityAsMissionEntity(policeDog, true, true)
                                ESX.ShowNotification('~g~Chien Spawn')
                            else
                                ESX.ShowNotification('~r~Chien Rentrer')
                                DeleteEntity(policeDog)
                            end
                        end
                    })
                    RageUI.Button(Config.Locales[Config.Locale]['Dogs_2'], nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            if DoesEntityExist(policeDog) then
                                if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), GetEntityCoords(policeDog), true) <= 5.0 then
                                    if IsEntityPlayingAnim(policeDog, "creatures@rottweiler@amb@world_dog_sitting@base", "base", 3) then
                                        ClearPedTasks(policeDog)
                                    else
                                        loadDict('rcmnigel1c')
                                        TaskPlayAnim(PlayerPedId(), 'rcmnigel1c', 'hailing_whistle_waive_a', 8.0, -8, -1, 120, 0, false, false, false)
                                        Wait(2000)
                                        loadDict("creatures@rottweiler@amb@world_dog_sitting@base")
                                        TaskPlayAnim(policeDog, "creatures@rottweiler@amb@world_dog_sitting@base", "base", 8.0, -8, -1, 1, 0, false, false, false)
                                    end
                                else
                                    ESX.ShowNotification('~r~Le chien est trop loin de vous !')
                                end
                            else
                                ESX.ShowNotification('~r~Vous n\'avez pas de chien !')
                            end
                        end
                    })
                    RageUI.Button(Config.Locales[Config.Locale]['Dogs_3'], nil, {RightLabel = '→→'}, true, {
                        onSelected = function()
                            local playerPed = PlayerPedId()
                            if DoesEntityExist(policeDog) then
                                if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), GetEntityCoords(policeDog), true) <= 5.0 then
                                    TaskGoToEntity(policeDog, playerPed, -1, 1.0, 10.0, 1073741824, 1)
                                else
                                    ESX.ShowNotification('~r~Le chien est trop loin de vous !')
                                end
                            else
                                ESX.ShowNotification('~r~Vous n\'avez pas de chien !')
                            end
                        end
                    })
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(askrenfort, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(Config.Confort_Infos) do
                        RageUI.Button(v.name, nil, {RightLabel = '→→'}, CooldownRenfort, {
                            onSelected = function()
                                CooldownRenfort = false
                                local _reason = v.reason 
                                local elements  = {}
                                local playerPed = PlayerPedId()
                                local coords  = GetEntityCoords(playerPed)
                                local name = GetPlayerName(PlayerId())
                                startUI(Config.ProgressBar.Time.Confort, Config.ProgressBar.Text['Confort'])
                                Wait(3000)
                                TriggerServerEvent('barwoz:renfort', coords, _reason)
                                CooldownRenfort = true
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
            end
        end)
    end
end

Keys.Register(Config.ControlF6, 'Police', 'F6 Police', function()
    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
        if MENU_POLICE == false then 
            OpenMenuPoliceF6()
        end
    end
end)