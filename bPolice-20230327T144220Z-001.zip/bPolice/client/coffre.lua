ESX = nil

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)

Style = {
    Line = { 10, 100, 170, 225 }
}
LineColor = Style

local MENU_POLICE = false

all_items = {}

local trunk = RageUI.CreateMenu(Config.Locales[Config.Locale]['Menu_Title6'], Config.Locales[Config.Locale]['Menu_SubTitle6'])
local stockplayer = RageUI.CreateSubMenu(trunk, Config.Locales[Config.Locale]['SubMenu_Title15'], Config.Locales[Config.Locale]['SubMenu_SubTitle15'])
local stockpolice = RageUI.CreateSubMenu(trunk, Config.Locales[Config.Locale]['SubMenu_Title16'], Config.Locales[Config.Locale]['SubMenu_SubTitle16'])
local weaponsplayer = RageUI.CreateSubMenu(trunk, Config.Locales[Config.Locale]['SubMenu_Title17'], Config.Locales[Config.Locale]['SubMenu_SubTitle17'])
local weaponspolice = RageUI.CreateSubMenu(trunk, Config.Locales[Config.Locale]['SubMenu_Title18'], Config.Locales[Config.Locale]['SubMenu_SubTitle18'])
trunk:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
stockplayer:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
stockpolice:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
weaponsplayer:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
weaponspolice:SetRectangleBanner(Style.Line[1], Style.Line[2], Style.Line[3], Style.Line[4])
trunk.Closed = function() 
    MENU_POLICE = false 
end

function OpenTrunkMenuPolice()
    if MENU_POLICE then
        MENU_POLICE = false
    else
        MENU_POLICE = true

        RageUI.Visible(trunk, true)
            CreateThread(function()
                while MENU_POLICE do 
                    Wait(1)
                    RageUI.IsVisible(trunk, function()
                        RageUI.Line(LineColor)
                        RageUI.Button("Déposer Objets !", nil, {RightLabel = ""}, true, {}, stockplayer)
                        RageUI.Button("Prendre Objets !", nil, {RightLabel = ""}, true, {
                            onSelected = function()
                                getStockPolice()
                            end
                        }, stockpolice)
                        RageUI.Line(LineColor)
                        RageUI.Button("Déposer Armes !", nil, {RightLabel = ""}, true, {}, weaponsplayer)
                        RageUI.Button("Prendre Armes !", nil, {RightLabel = ""}, true, {
                            onSelected = function()
                                getWeaponsPolice()
                            end
                        }, weaponspolice)
                        RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(stockplayer, function()
                    ESX.PlayerData = ESX.GetPlayerData()
                    RageUI.Line(LineColor)
                    for k, v in pairs(ESX.PlayerData.inventory) do
                        if v.count >= 1 then
                                    RageUI.Button(v.label, nil, {RightLabel = v.count}, true, {
                                        onSelected = function()
                                                local cbDeposer = KeyboardInput("Combien ?", '' , 15)
                                                TriggerServerEvent('barwoz:putStockItemsPolice', v.name, tonumber(cbDeposer), societe)
                                        end
                                    })
                        end
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(stockpolice, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(all_items) do
                        RageUI.Button(v.label, nil, {RightLabel = v.nb}, true, {
                            onSelected = function()
                                local count = KeyboardInput("Combien voulez vous en déposer",nil,4)
                                count = tonumber(count)
                                if count <= v.nb then
                                    TriggerServerEvent("barwoz:takeStockItemsPolice",v.item, count)
                                else
                                    ESX.ShowNotification("~r~Vous n'en avez pas assez sur vous")
                                end
                                getStockPolice()
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(weaponsplayer, function()
                    RageUI.Line(LineColor)
                    ESX.PlayerData = ESX.GetPlayerData()
                    ESX.WeaponData = ESX.GetWeaponList()

                    for i = 1, #ESX.WeaponData, 1 do
                        if ESX.WeaponData[i].name == 'WEAPON_UNARMED' then
                            ESX.WeaponData[i] = nil
                        else
                            ESX.WeaponData[i].hash = GetHashKey(ESX.WeaponData[i].name)
                        end
                    end
                    for i = 1, #ESX.WeaponData, 1 do
                        if HasPedGotWeapon(PlayerPedId(), ESX.WeaponData[i].hash, false) then
                            local ammo = GetAmmoInPedWeapon(PlayerPedId(), ESX.WeaponData[i].hash)
                            RageUI.Button('~r~→~s~ '..ESX.WeaponData[i].label..' (~b~'..ammo..'~s~)', nil, {}, true, {
                                onSelected = function()
                                    TriggerServerEvent('barwoz:putWeaponsPolice', ESX.WeaponData[i].name)
                                end
                            })
                        end
                    end
                    RageUI.Line(LineColor)
                end)
                RageUI.IsVisible(weaponspolice, function()
                    RageUI.Line(LineColor)
                    for k,v in pairs(all_weapons) do
                        RageUI.Button(v.name, nil, {RightLabel = v.count}, true, {
                            onSelected = function()
                                if v.count >= 1 then 
                                    TriggerServerEvent("barwoz:takeWeaponsPolice", v.name)
                                else
                                    ESX.ShowNotification("~r~L'entreprise n'en a pas assez !") 
                                end
                                getWeaponsPolice()
                            end
                        })
                    end
                    RageUI.Line(LineColor)
                end)
            end
        end)
    end
end

