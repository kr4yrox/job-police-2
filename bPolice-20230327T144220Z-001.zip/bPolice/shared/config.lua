Config = {}

Config = {
    ControlF6 = 'F6',
    InitESX   = 'esx:getSharedObject',
    Locale    = 'fr',
    green 	  = 56108,
    orange    = 16744192,
    red 	  = 16711680,
    yellow    = 16705372,
    blue 	  = 2061822,

    blipsPoliceJob = {
        {title="Commissariat | ~b~L.S.P.D~s~", colour=3, id=137, x = 438.72, y = -981.91, z = 30.68},
    },

    Webhook = {
        started = 'https://discord.com/api/webhooks/964191156118355968/hSHN_hWfvdvvkawL65z-lIkaCXqFlHaH1qlEntwgad4s0XeaP6GIDnnEuDfiUxwtkuX-',
        paused = 'https://discord.com/api/webhooks/964191969607815188/NO8-5zomWoN057e940d2-lUHA7eq6Y_9Sc5uX5E-h6FwTfhv1NpsO5nbCRSDnj8e0sEX',
        finished = 'https://discord.com/api/webhooks/964192048758530129/UPjjDcGDyS7nXFuA1kRnWJ0n9C3vMo5WkGlW8X6W8OLAFEztaZi-l_uIzWI8z8fDXkJf',
        standby = 'https://discord.com/api/webhooks/964192157349085225/6KrybCw_IJZy2e5TYDF9xgqnnZUyzsWJIT9LEOa1ooiiqUsyhZS-6HTMw12d5Xq41e14',
        armorie = 'https://discord.com/api/webhooks/964194694798139443/emPYcYp2OiMas750WpuA48G9I76HQYD0t6sK_jNPNAFIuA6-d59vN75_KjYGhx02__YX',
        takeItems = 'https://discord.com/api/webhooks/964195118108254310/0_pc5dqBlz3L8sX9BF_yiCZboJ-UtNypn0YLMpDnSYVI9zG_3S6tf3_QR5Ii6L52NTW0',
        putItems = 'https://discord.com/api/webhooks/964195118108254310/0_pc5dqBlz3L8sX9BF_yiCZboJ-UtNypn0YLMpDnSYVI9zG_3S6tf3_QR5Ii6L52NTW0',
        takeWeapons = 'https://discord.com/api/webhooks/964195118108254310/0_pc5dqBlz3L8sX9BF_yiCZboJ-UtNypn0YLMpDnSYVI9zG_3S6tf3_QR5Ii6L52NTW0',
        putWeapons = 'https://discord.com/api/webhooks/964195118108254310/0_pc5dqBlz3L8sX9BF_yiCZboJ-UtNypn0YLMpDnSYVI9zG_3S6tf3_QR5Ii6L52NTW0',
        casier = 'https://discord.com/api/webhooks/964195309188161556/8XTNKMJi9LnfVR82gAsboCM0hAEqaPOZc3guCcF_OU6dF1qy5v6-W4yJBDRp_R2OYAtp',
    },

    ProgressBar = {
        Text = {
            ['Fouille'] = "Fouille De la Personne en Cours...",
            ['Confort'] = "Envoie de la Demande en Cours...",
            ['Statues'] = "Changement de Statut en Cours...",
            ['Fouriere'] = "Mise en Fourière en Cours...",
            ['Vehicle_Open'] = "Ouverture du Véhicule en Cours...",
            ['Boss'] = "Accès a l'Ordinateur en Cours...",
            ['Cloack'] = "Ouverture de vôtre Casier en Cours...",
            ['CloackJail'] = "Dépos de vos Biens en Cours...",
            ['Weapon'] = "Ouverture de l'Armurerie en Cours...",
            ['Garage'] = "Ouverture du Garage en Cours...",
            ['Coffre'] = "Ouverture du Cofffre en Cours...",
        },
        Time = {
            Fouille = 5000,
            Confort = 3000,
            Statues = 3000,
            Fouriere = 8000,
            Vehicle_Open = 20000,
            Boss = 5000,
            Cloack = 5000,
            CloackJail = 5000,
            Weapon = 5000, 
            Garage = 5000,
            Coffre = 5000,
        },
    },

    Confort_Infos = {
        {name = 'Petite Demande (~g~Code-2~s~)', reason = "petite"},
        {name = 'Demande Importante (~o~Code-3~s~)', reason = "importante"},
        {name = 'Demande Très Importante (~r~Code-99~s~)', reason = "big_importante"},
    },

    Statues = {
        {name = 'Prise de Service (~g~Code-10.8~s~)', reason = "prise"},
        {name = 'Fin de Service (~r~Code-10.6~s~)', reason = "fin"},
        {name = 'Pause de Service (~o~Code-10.7~s~)', reason = "pause"},
        {name = 'En Attente de Dispatch (~y~Code-10.12~s~)', reason = "standby"},
    },
    
    Tenues = { -- Modifier les Tenues / Ajouter des Tenues au Menu
        {name = 'Tenue ~b~Cadet', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
        {name = 'Tenue ~b~Officier', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
        {name = 'Tenue ~b~Sergent', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
        {name = 'Tenue ~b~Lieutenant', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
        {name = 'Tenue ~b~Capitaine', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
        {name = 'Tenue ~b~Commandant', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
    },

    TenuesJail = {
        {name = 'Tenue ~b~Détenue', shirt1 = 58, shirt2 = 0, torse1 = 55, torce2 = 0, bras1 = 0, bras2 = 0, pantalon1 = 59, pantalon2 = 9, chaussure1 = 60, chaussure2 = 0, chaine1 = 0, chaine2 = 0, bproof1 = 4, bproof2 = 1},
    },

    Bullet = {
        {bullet1 = '4', bullet2 = '1'},
    },

    BulletCadet = {
        {bulletcadet1 = '59', bulletcadet2 = '1'},
    },

    Bag = {
        {bag1 = '44', bag2 = '1'},
    },

    Armes = {
        {grade = 0, name = 'weapon_flashlight', label = 'Lampe Torche'},
        {grade = 0, name = 'weapon_nightstick', label = 'Matraque'},
        {grade = 0, name = 'weapon_stungun', label = 'Tazer'},
        {grade = 0, name = 'weapon_combatpistol', label = 'Pistolet de Combat'},
        {grade = 2, name = 'weapon_shotgun', label = 'Fusils à Pompes'},
        {grade = 2, name = 'weapon_carbinerifle', label = 'Carabine d\'Assault'},
        {grade = 3, name = 'weapon_specialcarbine', label = 'Carabine Spécialisé'},
        {grade = 4, name = 'weapon_sniperrifle', label = 'Sniper'},
        {grade = 5, name = 'weapon_marksmanrifle', label = 'Sniper 2'},
    },

    VehiclePolice = {
        {model = 'police2', label = '~b~Buffalo~s~ Police'},
        {model = 'police', label = '~b~Cruiser~s~ Police'},
        {model = 'police3', label = '~b~4X4~s~ Police'},
        {model = 'policeb', label = '~b~Moto Classique~s~ Police'},
        {model = 'r1200rtp', label = '~b~Moto d\'Intervention~s~ Police'},
        {model = 'police4', label = '~b~Cruiser Banalisé~s~ Police'},
        {model = 'nkscout', label = '~b~4X4 Banalisé~s~ Police'},
        {model = 'ghispo2', label = '~b~Masserati~s~ Police'},
        {model = 'pol718', label = '~b~Porche~s~ Police'},
        {model = 'BEAR01', label = '~b~Riot~s~ Police'},
    },

    HeliPolice = {
        {model = 'maverick', label = '~b~Hélicoptère 1~s~ Police'},
        {model = 'frogger', label = '~b~Hélicoptère 2~s~ Police'},
        {model = 'buzzard', label = '~b~Hélicoptère 3~s~ Police'},
    },

    Fines = {
        -- {category="0", label="Name of Fines", amount="Price of Fines"},
        {category="0", label="Usage abusif du klaxon", amount="50"},
        {category="0", label="Franchir une ligne continue", amount="60"},
        {category="0", label="Circulation à contresens", amount="250"},
        {category="0", label="Demi-tour non autorisé", amount="350"},
        {category="0", label="Circulation hors-route", amount="200"},
        {category="0", label="Non-respect des distances de sécurité", amount="50"},
        {category="0", label="Arrêt dangereux interdit", amount="150"},
        {category="0", label="Stationnement gênant interdit", amount="85"},
        {category="0", label="Non-respect de la priorité à droite", amount="120"},
        {category="0", label="Non-respect à un véhicule prioritaire", amount="90"},
        {category="0", label="Non-respect d'un stop", amount="100"},
        {category="0", label="Non-respect d'un feu rouge", amount="400"},
        {category="0", label="Dépassement dangereux", amount="150"},
        {category="0", label="Véhicule non en état", amount="120"},
        {category="0", label="Conduite sans permis", amount="1500"},
        {category="0", label="Délit de fuite", amount="4000"},
        {category="0", label="Excès de vitesse < 5 km/h", amount="125"},
        {category="0", label="Excès de vitesse 5-15 km/h", amount="400"},
        {category="0", label="Excès de vitesse 15-30 km/h", amount="600"},
        {category="0", label="Excès de vitesse > 30 km/h", amount="850"},
        {category="0", label="Entrave de la circulation", amount="210"},
        {category="0", label="Dégradation de la voie publique", amount="135"},

     -- {category="1", label="Name of Fines", amount="Price of Fines"},
        {category="1", label="Trouble à l'ordre publique", amount="1750"},
        {category="1", label="Entrave opération de police", amount="3500"},
        {category="1", label="Insulte envers entre civils", amount="250"},
        {category="1", label="Menace verbale ou intimidation", amount="500"},
        {category="1", label="Manifestation illégale", amount="300"},
        {category="1", label="Tentative de corruption", amount="1000"},
        {category="1", label="Arme blanche sortie en ville", amount="5000"},
        {category="1", label="Arme léthale sortie en ville", amount="6000"},
        {category="1", label="Port d'arme non autorisé", amount="5000"},
        {category="1", label="Port d'arme illégal", amount="4000"},
        {category="1", label="Vol de voiture", amount="1800"},
        {category="1", label="Vente de drogue", amount="5000"},
        {category="1", label="Fabrication de drogue", amount="2000"},
        {category="1", label="Possession de drogue", amount="3500"},
        {category="1", label="Prise d'otage civil", amount="6000"},
        {category="1", label="Prise d'otage agent de l'état", amount="10000"},

     -- {category="2", label="Name of Fines", amount="Price of Fines"},
        {category="2", label="Braquage particulier", amount="15000"},
        {category="2", label="Braquage magasin", amount="7500"},
        {category="2", label="Braquage de banque", amount="10000"},
        {category="2", label="Tir sur civil", amount="5000"},
        {category="2", label="Tir sur agent de l'état", amount="7000"},
        {category="2", label="Tentative de meurtre sur civil", amount="7000"},
        {category="2", label="Tentative de meurtre sur policier", amount="9000"},
        {category="2", label="Meurtre sur civil", amount="12000"},
        {category="2", label="Meurtre sur agent de l'état", amount="15000"},
        {category="2", label="Meurtre involontaire", amount="8000"},
        {category="2", label="Escroquerie à l'entreprise ", amount="5000"},        
    },
    MarkerPolice = {
        ["Boss_Police"] = {
            value = 0,
            marker = true,
            position = vector3(462.26, -985.37, 30.72),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder à la gestion de la ~b~L.S.P.D~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Boss, Config.ProgressBar.Text['Boss'])
            end,
            interact2 = function()
                TriggerEvent('esx_society:openBossMenu', 'police', function(data, menu)
                    menu.close()
                end)
            end
        }, 
        ["Cloack_Police"] = {
            value = 0,
            marker = true,
            position = vector3(461.58, -999.17, 30.68),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder au vestiaire de la ~b~L.S.P.D~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Cloack, Config.ProgressBar.Text['Cloack'])
            end,
            interact2 = function()
                OpenCloakMenuPolice()
            end
        }, 
        ["CloackJail_Police"] = {
            value = 1,
            marker = true,
            position = vector3(473.15, -1007.67, 26.27),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour déposer vos ~b~Effets Personnels~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.CloackJail, Config.ProgressBar.Text['CloackJail'])
            end,
            interact2 = function()
                OpenCloakMenuJail()
            end
        }, 
        ["Weapon_Police"] = {
            value = 0,
            marker = true,
            position = vector3(482.61, -995.63, 30.68),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder à l'~b~Armurerie~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Weapon, Config.ProgressBar.Text['Weapon'])
            end,
            interact2 = function()
                OpenWeaponMenuPolice()
            end
        }, 
        ["Garage_Police1"] = {
            value = 0,
            marker = true,
            position = vector3(458.85, -992.73, 25.69),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder au ~b~Garage~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Garage, Config.ProgressBar.Text['Garage'])
            end,
            interact2 = function()
                OpenGarageMenuPolice()
            end
        }, 
        ["Garage_Police2"] = {
            value = 0,
            marker = true,
            position = vector3(475.42, -1026.86, 28.1),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder au ~b~Garage~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Garage, Config.ProgressBar.Text['Garage'])
            end,
            interact2 = function()
                OpenGarageMenuPolice()
            end
        }, 
        ["Coffre_Police"] = {
            value = 0,
            marker = true,
            position = vector3(472.87, -996.31, 26.27),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder au ~b~Coffre~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Coffre, Config.ProgressBar.Text['Coffre'])
            end,
            interact2 = function()
                OpenTrunkMenuPolice()
            end
        }, 
        ["Heli_Police"] = {
            value = 0,
            marker = true,
            position = vector3(449.10, -981.22, 43.69),
            color = {r = 150, g = 0, b = 40, a = 255},
            help = "Appuyez sur [~b~E~s~] pour accèder au ~b~Garage~s~ !",
            interact = function()
                startUI(Config.ProgressBar.Time.Garage, Config.ProgressBar.Text['Garage'])
            end,
            interact2 = function()
                OpenGarageHeliMenuPolice()
            end
        }, 
    }
}

Config.Locales = {
    ['fr'] = {
        ['Menu_Title'] = 'bPolice',
        ['Menu_SubTitle'] = 'Vôtre Grade : ~y~',
        ['Menu_Title2'] = 'bPolice',
        ['Menu_SubTitle2'] = 'Vôtre Casier de la ~y~Police~s~ :',
        ['Menu_Title3'] = 'bPolice',
        ['Menu_SubTitle3'] = 'Déposer ses Effets Personnels :',
        ['Menu_Title4'] = 'bPolice',
        ['Menu_SubTitle4'] = 'Prends tes Armes de la ~y~Police~s~ :',
        ['Menu_Title5'] = 'bPolice',
        ['Menu_SubTitle5'] = 'Choisis un Véhicule de la ~y~Police~s~ :',
        ['Menu_Title6'] = 'bPolice',
        ['Menu_SubTitle6'] = 'Voici le Coffre de la ~y~Police~s~ :',
        ['Menu_Title7'] = 'bPolice',
        ['Menu_SubTitle7'] = 'Choisis un Hélicoptère de la ~y~Police~s~ :',
        ['Interact_Person'] = 'Intéractions Civils',
        ['Casier'] = 'Intéractions Casiers',
        ['Menottes'] = 'Menu Menottes', 
        ['Interact_Veh'] = 'Intéractions Véhicules',
        ['Amende'] = 'Donner une Amende', 
        ['Statues'] = 'Status de l\'Agent',
        ['Dogs'] = 'Intéractions Chiens',
        ['Object'] = 'Menu Objets',
        ['Renfort'] = 'Demande de Renfort',  
        ['Quit'] = 'Fermer le Menu Police',      
        ['SubMenu_Title1'] = 'bPolice',
        ['SubMenu_SubTitle1'] = 'Intéractions ~y~Citoyens~s~ :',
        ['Identity_Card'] = 'Carte Identité',
        ['Fouille'] = 'Fouiller',
        ['Amendes'] = 'Amendes',
        ['SubMenu_Title3'] = 'bPolice',
        ['SubMenu_SubTitle3'] = 'Intéractions ~y~Status~s~ :',
        ['SubMenu_Title2'] = 'bPolice',
        ['SubMenu_SubTitle2'] = 'Intéractions ~y~Citoyens~s~ :',
        ['LastName'] = 'Nom : ~b~',
        ['FirstName'] = 'Prénom : ~b~',
        ['Sex'] = 'Sexe : ~b~',
        ['DateOfBirth'] = 'Date de Naissance : ~b~',
        ['Height'] = 'Taille : ~b~',
        ['Job'] = 'Métier : ~b~',
        ['ID'] = 'ID : ~b~',
        ['SubMenu_Title11'] = 'bPolice',
        ['SubMenu_SubTitle11'] = 'Demander du ~y~Renfort~s~ :',
        ['Filter_Fouille'] = 'Filtre Infos',
        ['Money'] = 'Liquide : ~g~',
        ['BlackMoney'] = 'Argent Sale : ~r~',
        ['SubMenu_Title5'] = 'bPolice',
        ['SubMenu_SubTitle5'] = 'Donner des ~y~Amendes~s~ :',
        ['Fines_1'] = 'Amendes Code de la Route',
        ['Fines_2'] = 'Amendes Citoyens',
        ['Fines_3'] = 'Amendes de Catégorie Supérieur',
        ['SubMenu_Title6'] = 'bPolice',
        ['SubMenu_SubTitle6'] = 'Amendes ~y~Code de la Route~s~ :',
        ['SubMenu_Title7'] = 'bPolice',
        ['SubMenu_SubTitle7'] = 'Amendes ~y~Citoyens~s~ :',
        ['SubMenu_Title8'] = 'bPolice',
        ['SubMenu_SubTitle8'] = 'Amendes de ~y~Catégorie Supérieur~s~ :',
        ['SubMenu_Title9'] = 'bPolice',
        ['SubMenu_SubTitle9'] = 'Gérer les Casiers ~y~Judiciaires~s~ :',
        ['SubMenu_Title10'] = 'bPolice',
        ['SubMenu_SubTitle10'] = 'Intéractions ~y~Menottes~s~ :',
        ['SubMenu_Title12'] = 'bPolice',
        ['SubMenu_SubTitle12'] = 'Intéractions ~y~Véhicules~s~ :',
        ['Fouriere'] = 'Mettre le Véhicule en ~b~Fourière',
        ['Open_Vehicle'] = 'Ouvir de Force le ~b~Véhicule',
        ['Get_Plate'] = 'Chercher les ~b~Informations~s~ du ~b~Véhicule',
        ['SubMenu_Title13'] = 'bPolice',
        ['SubMenu_SubTitle13'] = 'Informations du  ~y~Véhicule~s~ :',
        ['Plate'] = 'Plaque du Véhicule : ~b~',
        ['NameP_Veh'] = 'Propriétaire : ~b~',
        ['SubMenu_Title14'] = 'bPolice',
        ['SubMenu_SubTitle14'] = 'Gestions du ~y~Chiens~s~ :',
        ['Dogs_1'] = "Sortir/Rentrer le ~b~Chien",
        ['Dogs_2'] = "Dire au ~b~Chien~s~ de s'assoire",
        ['Dogs_3'] = "Faire Suivre le ~b~Chien",
        ['Took_Bullet'] = "Mettre ~b~GPB~s~",
        ['Took_BulletCadet'] = "Mettre ~b~Gillet Cadet~s~",
        ['Took_Bag'] = "Prendre un ~b~Sac~s~",
        ['SubMenu_Title15'] = 'bPolice',
        ['SubMenu_SubTitle15'] = 'Voici vôtre ~y~Inventaire~s~ :',
        ['SubMenu_Title16'] = 'bPolice',
        ['SubMenu_SubTitle16'] = 'Voici le Stock de la ~y~Police~s~ :',
    },
    ['en'] = {
        ['Menu_Title'] = 'bPolice',
        ['Menu_SubTitle'] = 'Your Rank : ~y~',
        ['Menu_Title2'] = 'bPolice',
        ['Menu_SubTitle2'] = 'Your ~y~Police~s~ Locker :',
        ['Menu_Title3'] = 'bPolice',
        ['Menu_SubTitle3'] = 'Deposit your Personal Effects:',
        ['Menu_Title4'] = 'bPolice',
        ['Menu_SubTitle4'] = 'Take your ~y~Police~s~ Weapon:',
        ['Menu_Title5'] = 'bPolice',
        ['Menu_SubTitle5'] = 'Take your ~y~Police~s~ Car:',
        ['Menu_Title6'] = 'bPolice',
        ['Menu_SubTitle6'] = 'This is the ~y~Police~s~ Chest:',
        ['Menu_Title7'] = 'bPolice',
        ['Menu_SubTitle7'] = 'Take your ~y~Police~s~ Car:',
        ['Interact_Person'] = 'Civilian interactions',
        ['Casier'] = 'Locker Interfaces',
        ['Menottes'] = 'Handcuffs menu', 
        ['Interact_Veh'] = 'Vehicle Interactions',
        ['Amende'] = 'Giving a fine', 
        ['Statues'] = 'Status of the Agent',
        ['Dogs'] = 'Dogs interactions',
        ['Object'] = 'Objects menu',
        ['Renfort'] = 'Request for Reinforcement',  
        ['Quit'] = 'Close the Font Menu',      
        ['SubMenu_Title1'] = 'bPolice',
        ['SubMenu_SubTitle1'] = 'Interactions ~y~Citizens~s~ :',
        ['Identity_Card'] = 'Identity card',
        ['Fouille'] = 'FouilleSearchr',
        ['Amendes'] = 'AmenFinesdes',
        ['SubMenu_Title3'] = 'bPolice',
        ['SubMenu_SubTitle3'] = 'Interactions ~y~Status~s~ :',
        ['SubMenu_Title2'] = 'bPolice',
        ['SubMenu_SubTitle2'] = 'Interactions ~y~Citizens~s~ :',
        ['LastName'] = 'LastName : ~b~',
        ['FirstName'] = 'FirstName : ~b~',
        ['Sex'] = 'Gender : ~b~',
        ['DateOfBirth'] = 'Date of Birth : ~b~',
        ['Height'] = 'Height : ~b~',
        ['Job'] = 'Job : ~b~',
        ['ID'] = 'ID : ~b~',
        ['SubMenu_Title11'] = 'bPolice',
        ['SubMenu_SubTitle11'] = 'Ask for ~y~Renforcement~s~ :',
        ['Filter_Fouille'] = 'Info Filter',
        ['Money'] = 'Liquid : ~g~',
        ['BlackMoney'] = 'Money Sale : ~r~',
        ['SubMenu_Title5'] = 'bPolice',
        ['SubMenu_SubTitle5'] = 'Giving ~y~Fines~s~ :',
        ['Fines_1'] = 'Traffic fines',
        ['Fines_2'] = 'Citizen Fines',
        ['Fines_3'] = 'Higher category fines',
        ['SubMenu_Title6'] = 'bPolice',
        ['SubMenu_SubTitle6'] = 'Fines ~y~Code of the Road~s~:',
        ['SubMenu_Title7'] = 'bPolice',
        ['SubMenu_SubTitle7'] = 'Fines ~y~Citizens~s~ :',
        ['SubMenu_Title8'] = 'bPolice',
        ['SubMenu_SubTitle8'] = 'Fines of ~y~Higher~Category~s~:',
        ['SubMenu_Title9'] = 'bPolice',
        ['SubMenu_SubTitle9'] = 'Manage ~y~Judicial Records~ :',
        ['SubMenu_Title10'] = 'bPolice',
        ['SubMenu_SubTitle10'] = 'Interactions ~y~Custody~s~:',
        ['SubMenu_Title12'] = 'bPolice',
        ['SubMenu_SubTitle12'] = 'Interactions ~y~Vehicles~s~ :',
        ['Fouriere'] = 'Put Vehicle in ~b~Fouriere',
        ['Open_Vehicle'] = 'Force open the ~b~Vehicle',
        ['Get_Plate'] = 'Get the ~b~Vehicles~ information',
        ['SubMenu_Title13'] = 'bPolice',
        ['SubMenu_SubTitle13'] = 'Information of ~y~Vehicle~s~:',
        ['Plate'] = 'Vehicle Plate: ~b~',
        ['NameP_Veh'] = 'Owner: ~b~',
        ['SubMenu_Title14'] = 'bPolice',
        ['SubMenu_SubTitle14'] = 'Management of ~y~Dogs~s~:',
        ['Dogs_1'] = 'Take the ~b~Dog out/In',
        ['Dogs_2'] = 'Tell the ~b~Dog~s~ to sit',
        ['Dogs_3'] = "Make the ~b~Dog~ follow",
        ['Took_Bullet'] = "Put ~b~GPB~s~",
        ['Took_BulletCadet'] = "Put ~b~Gillet Cadet~s~",
        ['Took_Bag'] = "Take a ~b~Bag~s~",
        ['SubMenu_Title15'] = 'bPolice',
        ['SubMenu_SubTitle15'] = 'This is your ~y~Inventory~s~:',
        ['SubMenu_Title16'] = 'bPolice',
        ['SubMenu_SubTitle16'] = 'This is the ~y~Police~s~ Stock:',
    },
}

