ESX = nil 

    TriggerEvent(Config.InitESX, function(obj) ESX = obj end)

    TriggerEvent('esx_phone:registerNumber', 'police', 'alerte police', true, true)

----- Fonction Logs 
function sendToDiscord(webhook, name, message, color)
    local DiscordWebHook = webhook  
    local embeds = {
        {
            ["title"] = name,
            ["description"] = message,
            ["type"] = "rich",
            ["color"] = color,
            ["footer"] =  {
                ["text"] = "Barwoz.Dev | Memory's :)",
            },
        }
    }
  
    if message == nil or message == '' then 
        return FALSE 
    end
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({username = name, embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

----- Get Infos Player

----- Infos Target
ESX.RegisterServerCallback('barwoz:sendInfosPlayerTrg', function(source, callback, target)
    local identifier = GetPlayerIdentifiers(target)[1]
    local Info_Player = {}

    MySQL.Async.fetchAll('SELECT firstname, lastname, dateofbirth, sex, height, job, money FROM users WHERE identifier = @identifier',
    {
        ['@identifier'] = identifier
    },
    function(data)
        table.insert(Info_Player, {
            identifier = data[1]['identifier'],
            FirstName = data[1]['firstname'],
            LastName = data[1]['lastname'],
            DateOfBirth = data[1]['dateofbirth'],
            Sex = data[1]['sex'],
            Height = data[1]['height'],
            Job = data[1]['job'],
            Money = data[1]['money'],
        })
        callback(Info_Player)
    end)
end)

----- BlackMoney
ESX.RegisterServerCallback('barwoz:sendBlackMoneyPlayer', function(source, callback, target)
    local identifier = GetPlayerIdentifiers(target)[1]
    local BalckMoney_Player = {}

    MySQL.Async.fetchAll('SELECT money FROM user_accounts WHERE identifier = @identifier',
    {
        ['@identifier'] = identifier
    },
    function(data)
        table.insert(BalckMoney_Player, {
            identifier = data[1]['identifier'],
            BlackMoney = data[1]['money'],
        })
        callback(BalckMoney_Player)
    end)
end)

----- Items
ESX.RegisterServerCallback('barwoz:sendItemPlayer', function(source, callback, target)
    local xPlayer = ESX.GetPlayerFromId(target)

    if xPlayer then
        local data = {
            inventory = xPlayer.getInventory(),
            weapons = xPlayer.getLoadout(),
        }
        callback(data)
    end
end)

----- Demande de Renfort
RegisterServerEvent('barwoz:renfort')
AddEventHandler('barwoz:renfort', function(coords, raison)
	local _source = source
	local _raison = raison
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		-- if thePlayer.job.name == 'police' then
			TriggerClientEvent('barwoz:renfortBlip', xPlayers[i], coords, _raison)
		-- end
	end
end)

----- Statut de l'Agent
RegisterServerEvent('barwoz:statues')
AddEventHandler('barwoz:statues', function(reason)
	local _source = source
	local _raison = reason
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()
	local name = xPlayer.getName(_source)

	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		-- if thePlayer.job.name == 'police' then
			TriggerClientEvent('barwoz:InfoService', xPlayers[i], _raison, name)
		-- end
	end

    if _raison == 'prise' then 
        sendToDiscord(Config.Webhook.started, 'Prise de Service' , "_**"..xPlayer.name.."**_ Vient de **Prendre** son Service", Config.green)
    elseif _raison == 'pause' then
        sendToDiscord(Config.Webhook.paused, 'Pause de Service' , "_**"..xPlayer.name.."**_ Vient de Prendre sa **Pause** de Service", Config.orange)
    elseif _raison == 'fin' then
        sendToDiscord(Config.Webhook.finished, 'Fin de Service' , "_**"..xPlayer.name.."**_ Vient de **Terminer** son Service", Config.red)
    elseif _raison == 'standby' then
        sendToDiscord(Config.Webhook.standby, 'Mise en Standby' , "_**"..xPlayer.name.."**_ Vient de se Mettre en **Standby* afin d'Attendre les Ordres", Config.yellow)
    end
end)

----- Saved Player
RegisterServerEvent('barwoz:SavedPlayer')
AddEventHandler('barwoz:SavedPlayer', function()
    ESX.SavePlayers()
end)

----- Prendre des Items
RegisterServerEvent('barwoz:TakeItems')
AddEventHandler('barwoz:TakeItems', function(target, itemType, itemName, itemCount)
    local _source = source
    local sourceXPlayer = ESX.GetPlayerFromId(_source)
    local targetXPlayer = ESX.GetPlayerFromId(target)

    if itemType == 'item_standard' then
        local targetItem = targetXPlayer.getInventoryItem(itemName)
		local sourceItem = sourceXPlayer.getInventoryItem(itemName)

        targetXPlayer.removeInventoryItem(itemName, itemCount)
        sourceXPlayer.addInventoryItem(itemName, itemCount)
        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..itemCount..' '..sourceItem.label.."~s~.")
        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a pris ~b~"..itemCount..' '..sourceItem.label.."~s~.")
        ESX.SavePlayers()
    elseif itemType == 'item_weapon' then
        targetXPlayer.removeWeapon(itemName, itemCount)
        sourceXPlayer.addWeapon   (itemName, itemCount)
        
        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..ESX.GetWeaponLabel(itemName).."~s~ avec ~b~"..itemCount.."~s~ balle(s).")
        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a confisqué ~b~"..ESX.GetWeaponLabel(itemName).."~s~ avec ~b~"..itemCount.."~s~ balle(s).")
        ESX.SavePlayers()
    elseif itemType == 'item_account' then
        targetXPlayer.removeAccountMoney(itemName, itemCount)
        sourceXPlayer.addAccountMoney(itemName, itemCount)

        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..itemCount.."$ d'argent sale~s~.")
        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a confisqué ~b~"..itemCount.."$ d'argent sale~s~.")
        ESX.SavePlayers()
    elseif itemType == 'item_money' then
        targetXPlayer.removeMoney(itemCount)
        sourceXPlayer.addMoney(itemCount)
        
        TriggerClientEvent("esx:showNotification", source, "Vous avez confisqué ~b~"..itemCount.."$ d'argent liquide~s~.")
        TriggerClientEvent("esx:showNotification", target, "Quelqu'un vous a confisqué ~b~"..itemCount.."$ d'argent liquide~s~.")
        ESX.SavePlayers()
    end
end)

----- Mettre les Menottes
RegisterServerEvent('barwoz:mettremenotte')
AddEventHandler('barwoz:mettremenotte', function(targetid, playerheading, playerCoords,  playerlocation)
    local _source = source
    TriggerClientEvent('barwoz:mettreM', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('barwoz:animarrest', _source)
end)

----- Enlever les menottes
RegisterServerEvent('barwoz:enlevermenotte')
AddEventHandler('barwoz:enlevermenotte', function(targetid, playerheading, playerCoords,  playerlocation)
    local _source = source
    TriggerClientEvent('barwoz:enleverM', targetid, playerheading, playerCoords, playerlocation)
    TriggerClientEvent('barwoz:animenlevermenottes', _source)
end)

----- Mettre dans un Véhicule
RegisterNetEvent('barwoz:putInVehicle')
AddEventHandler('barwoz:putInVehicle', function(target)
	TriggerClientEvent('barwoz:putInVehicle', target)
end)

----- Sortir d'un Véhicule

RegisterNetEvent('barwoz:OutVehicle')
AddEventHandler('barwoz:OutVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('barwoz:OutVehicle', target)
end)

----- Get Infos Véhicules
ESX.RegisterServerCallback('barwoz:getInfosVehicle', function(source, cb, plate)
    local Info_Vehicle = {}

    MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
        ['@plate'] = plate
    }, function(result)

        if result[1] == nil then 
            cb('rien')
        else
            MySQL.Async.fetchAll('SELECT firstname, lastname, sex, job FROM users WHERE identifier = @identifier',
            {
                ['@identifier'] = result[1].owner
            },
            function(data)
                table.insert(Info_Vehicle, {
                    identifier = data[1].identifier,
                    FirstName = data[1].firstname,
                    LastName = data[1].lastname,
                    Sex = data[1].sex,
                    Job = data[1].job,
                })
                cb(Info_Vehicle)
            end)
        end
    end)
end)

----- Take Weapons
RegisterServerEvent('barwoz:TakeWeaponsPolice')
AddEventHandler('barwoz:TakeWeaponsPolice', function(model, label)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(source)

        xPlayer.addWeapon(model, 200)
        TriggerClientEvent('esx:showAdvancedNotification', source, 'L.S.P.D', '', 'Vous avez reçus votre ~b~'..label, 'CHAR_CALL911', 8)
        sendToDiscord(Config.Webhook.armorie, 'Armurerie Police' , "_**"..xPlayer.name.."**_ Vient de Prendre : **"..label.."** dans l'Armurerie", Config.blue)
end)

----------------------Coffre
-----Get Police
ESX.RegisterServerCallback('barwoz:getStockItemsPolice', function(source, cb)
	local all_items = {}
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)
		for k,v in pairs(inventory.items) do
			if v.count > 0 then
				table.insert(all_items, {label = v.label, item = v.name, nb = v.count})
			end
		end

	end)
	cb(all_items)
end)

-----Prendre
RegisterServerEvent('barwoz:takeStockItemsPolice')
AddEventHandler('barwoz:takeStockItemsPolice', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)
			xPlayer.addInventoryItem(itemName, count)
			inventory.removeItem(itemName, count)
	end)
    sendToDiscord(Config.Webhook.takeItems, 'Retrait du Coffre' , "_**"..xPlayer.name.."**_ Vient de Prendre : **"..itemName.." x"..count.."** dans le Coffre de la L.S.P.D", Config.red)
end)

-----Déposer
RegisterNetEvent('barwoz:putStockItemsPolice')
AddEventHandler('barwoz:putStockItemsPolice', function(itemName, count, society)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_police', function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			TriggerClientEvent('esx:showAdvancedNotification', _src, 'Coffre', '~b~Informations~s~', 'Vous avez déposé ~g~'..inventoryItem.label.." x"..count, 'CHAR_MP_FM_CONTACT', 8)
            sendToDiscord(Config.Webhook.putItems, 'Dépos du Coffre' , "_**"..xPlayer.name.."**_ Vient de Déposer : **"..itemName.." x"..count.."** dans le Coffre de la L.S.P.D", Config.green)
		else
			TriggerClientEvent('esx:showAdvancedNotification', _src, 'Coffre', '~b~Informations~s~', "Quantité ~r~invalide", 'CHAR_MP_FM_CONTACT', 9)
		end
	end)
end)

----- Get Weapons Data
ESX.RegisterServerCallback('barwoz:getWeaponsPolice', function(source, cb)
	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)
		local weapons = store.get('weapons')

		if weapons == nil then
			weapons = {}
		end
		cb(weapons)
	end)
end)

-----Prendre
RegisterNetEvent('barwoz:takeWeaponsPolice')
AddEventHandler('barwoz:takeWeaponsPolice', function(weaponName, count)
    local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addWeapon(weaponName, 200)

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)
		local weapons = store.get('weapons') or {}
		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = (weapons[i].count > 0 and weapons[i].count - 1 or 0)
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name = weaponName,
				count = count
			})
		end

		store.set('weapons', weapons)
        sendToDiscord(Config.Webhook.takeWeapons, 'Retrait du Coffre' , "_**"..xPlayer.name.."**_ Vient de Prendre : **"..weaponName.."** dans le Coffre de la L.S.P.D", Config.red)
	end)
end)

-----Déposer
RegisterNetEvent('barwoz:putWeaponsPolice')
AddEventHandler('barwoz:putWeaponsPolice', function(weaponName)
    local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeWeapon(weaponName)

	TriggerEvent('esx_datastore:getSharedDataStore', 'society_police', function(store)
		local weapons = store.get('weapons') or {}
		local foundWeapon = false

		for i=1, #weapons, 1 do
			if weapons[i].name == weaponName then
				weapons[i].count = weapons[i].count + 1
				foundWeapon = true
				break
			end
		end

		if not foundWeapon then
			table.insert(weapons, {
				name  = weaponName,
				count = 1
			})
		end

		store.set('weapons', weapons)
	end)
    sendToDiscord(Config.Webhook.putWeapons, 'Dépos du Coffre' , "_**"..xPlayer.name.."**_ Vient de Déposer : **"..weaponName.."** dans le Coffre de la L.S.P.D", Config.green)
end)

----- Saved Casier Police
RegisterNetEvent('barwoz:savedCasierPolice')
AddEventHandler('barwoz:savedCasierPolice', function(lastname, firstname, dateofbirth, height, dateofcrimes, crimes, sanctions)
    local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.execute('INSERT INTO casier_police (lastname, firstname, dateofbirth, height, dateofcrimes, crimes, sanctions) VALUES (@lastname, @firstname, @dateofbirth, @height, @dateofcrimes, @crimes, @sanctions)', 
    {
        ['@lastname']     = lastname,
        ['@firstname']    = firstname,
        ['@dateofbirth']  = dateofbirth,
        ['@height']       = height,
        ['@dateofcrimes'] = dateofcrimes,
        ['@crimes']       = crimes,
        ['@sanctions']    = sanctions,
    })

    sendToDiscord(Config.Webhook.casier, 'Casiers' , "__**"..xPlayer.name.."**__ Vient de Créer un Casier pour **"..lastname.." "..firstname.."** avec comme motifs et sanctions : \n\n **__Motifs :__**\n "..crimes.."\n\n **__Sanctions :__** \n"..sanctions , Config.red)
end)

----- Get Casier Police
ESX.RegisterServerCallback('barwoz:getCasierPolice', function(source, callback, lastname)
    local Info_PlayerCasier = {}
    local result = {}

    MySQL.Async.fetchAll('SELECT lastname, firstname, dateofbirth, height, dateofcrimes, crimes, sanctions FROM casier_police WHERE lastname = @lastname',
    {
        ['@lastname'] = lastname
    },
    function(data)
        for i=1, #data do 
            table.insert(Info_PlayerCasier, {
                LastName_Casier     = data[i]["lastname"],
                FirstName_Casier    = data[i]["firstname"],
                DateOfBirth_Casier  = data[i]["dateofbirth"],
                Height_Casier       = data[i]["height"],
                DateOfCrimes_Casier = data[i]["dateofcrimes"],
                Crimes_Casier       = data[i]["crimes"],
                Sanctions_Casier    = data[i]["sanctions"],
            })
        end
        callback(Info_PlayerCasier)
    end)
end)

RegisterServerEvent('TireEntenduServeur')
AddEventHandler('TireEntenduServeur', function(gx, gy, gz)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('TireEntendu', xPlayers[i], gx, gy, gz)
		end
	end
end)

